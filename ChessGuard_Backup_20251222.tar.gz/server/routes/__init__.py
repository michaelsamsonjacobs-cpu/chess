"""FastAPI routers exposed by the ChessGuard backend."""
