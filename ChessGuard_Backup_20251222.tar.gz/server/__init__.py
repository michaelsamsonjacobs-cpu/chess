"""Backend package for ChessGuard."""
