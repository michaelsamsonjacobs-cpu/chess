"""Service layer helpers used by the ChessGuard backend."""
